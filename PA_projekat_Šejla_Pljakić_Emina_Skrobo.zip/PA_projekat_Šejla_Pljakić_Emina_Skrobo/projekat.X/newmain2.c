#include <xc.h>

#pragma config FOSC=HS,WDTE=OFF,PWRTE=OFF,MCLRE=ON,CP=ON,CPD=OFF,BOREN=OFF,CLKOUTEN=OFF
#pragma config IESO=OFF,FCMEN=OFF,WRT=OFF,VCAPEN=OFF,PLLEN=OFF,STVREN=OFF,LVP=OFF
#define _XTAL_FREQ 8000000

#define red1   PORTCbits.RC5
#define red2   PORTDbits.RD1
#define red3   PORTDbits.RD2
#define red4   PORTDbits.RD3
#define kol1   PORTDbits.RD4
#define kol2   PORTDbits.RD5
#define kol3   PORTDbits.RD6
#define kol4   PORTDbits.RD7


unsigned char operacija=0;
int broj1=0, broj2=0;
char adresiran;
unsigned char cifra=0;
char prijem;

unsigned char skeniranje() {
	red1=1;
	red2=1;
	red3=1;
	red4=1;
    __delay_us(30);
    
    red1=0;
	red2=1;
	red3=1;
	red4=1;
    __delay_us(30);

	if (kol1 == 0) {__delay_ms(100); while (kol1==0); return '1';}
	if (kol2 == 0) {__delay_ms(100); while (kol2==0); return '2';}
	if (kol3 == 0) {__delay_ms(100); while (kol3==0); return '3';}
	if (kol4 == 0) {__delay_ms(100); while (kol4==0); return '+';}
	
	red1=1;
	red2=0;
	red3=1;
	red4=1;
    __delay_us(30);

	if (kol1 == 0) {__delay_ms(100); while (kol1==0); return '4';}
	if (kol2 == 0) {__delay_ms(100); while (kol2==0); return '5';}
	if (kol3 == 0) {__delay_ms(100); while (kol3==0); return '6';}
	if (kol4 == 0) {__delay_ms(100); while (kol4==0); return '-';}
	
	red1=1;
	red2=1;
	red3=0;
	red4=1;
    __delay_us(30);

	if (kol1 == 0) {__delay_ms(100); while (kol1==0); return '7';}
	if (kol2 == 0) {__delay_ms(100); while (kol2==0); return '8';}
	if (kol3 == 0) {__delay_ms(100); while (kol3==0); return '9';}
	if (kol4 == 0) {__delay_ms(100); while (kol4==0); return '*';}
	
	red1=1;
	red2=1;
	red3=1;
	red4=0;
     __delay_us(30);

	if (kol1 == 0) {__delay_ms(100); while (kol1==0); return '.';}
	if (kol2 == 0) {__delay_ms(100); while (kol2==0); return '0';}
	if (kol3 == 0) {__delay_ms(100); while (kol3==0); return '=';}
	if (kol4 == 0) {__delay_ms(100); while (kol4==0); return '/';}

return 0xFF;
}

void init_serial()
{
    TRISC6=0;  //RC6/TX IZLAZ
    TRISC7=1;  //RS7/RX ULAZ
    BAUDCONbits.BRG16=0;
    BRGH=0;
    SPBRG=12; //za 9600 na Fosc=8MHz
    SYNC=0;	// Asinhrona komunikacija
	SPEN=1;	// Aktiviranje serijskog porta
	//RCIE=0; // Onemogucavanje interrupta na serijskom portu
    CREN=0; // Ukljucivanje/iskljucivanje prijemnika
    //**Select 8-bit mode**//  
   // TX9   = 0;    // 8-bit reception selected
//    RX9   = 0;    // 8-bit reception mode selected
    
}

void spremi_cifru(char znak){
        if (!operacija) {
			broj1 = broj1 * 10 + znak-'0';
        } else{
			broj2= broj2 * 10 + znak-'0';
		}
       if(znak=='+' || znak=='-' || znak=='*' || znak=='/'){
    		operacija= znak;}
}  
void izracunaj(){
    if(operacija == '+')
        broj1 = broj1 + broj2;   
     if(operacija == '-')
        broj1 = broj1 - broj2; 
     if(operacija == '*')
      broj1 = broj1 * broj2;  
     if(operacija == '/')
       broj1 = broj1 / broj2;  
}

void unos_i_slanje_Cifre(){          
        
      do{
            cifra=skeniranje();
        }while(cifra==0xFF);
        LATB=cifra;
        spremi_cifru(cifra);
        TXSTAbits.TXEN=1;
        TXREG=cifra;
        while (!TXIF);
         __delay_ms(10);
        TXSTAbits.TXEN=0; 
}
void main(void) {
    TRISD=0xF0;
    ANSELD=0x00;
    PORTD=0x0F;
    TRISC5=0;
    TRISB=0x00;
    LATB=0x00;
    init_serial(); 
    while(1){ 
        if(cifra!='=') unos_i_slanje_Cifre(); 
     
         else {
            int bio=0,i=0;
            LATB=0XF0;
            broj1/=10;
            broj1++;
            broj2/=10;
            broj2=broj2-1;
            if(broj2==0 && operacija=='/'){
                TXSTAbits.TXEN=1;
                char znak='E';
                TXREG=znak;
                while (!TXIF);
                __delay_ms(10);
                TXSTAbits.TXEN=0;
                i++;
            }
            else{
                izracunaj();
                char rezultat[12];
                int tmp=0;
                tmp = broj1;
                 // prebrojavamo cifre
                int broj_cifara=0;
                i=0;
                if(broj1<0){
                    TXSTAbits.TXEN=1;
                    rezultat[i] = '-';
                    TXREG=rezultat[i];
                    while (!TXIF);
                    __delay_ms(10);
                    TXSTAbits.TXEN=0;
                    broj1=-broj1; 
                    bio=1;
                }
                tmp = broj1;
                do {
                    tmp /= 10;
                    broj_cifara++;
                } while (tmp != 0);
                i=broj_cifara;
                LATB=i;


                 while(broj1!=0){
                    i--; 
                    rezultat[i]= broj1 % 10 + '0';
                    broj1 /= 10;
                 }

                 i=0;
                while (i != broj_cifara)
                {
                    if(bio==1) i++; //da ne prepise reko znaka - vec da ostane -
                    TXSTAbits.TXEN=1;
                    TXREG= rezultat[i]; 
                    while (!TXIF);
                    __delay_ms(100);
                    TXSTAbits.TXEN=0;  
                    i++;  
                }
                    TXSTAbits.TXEN=1;
                    char znak='.';
                    TXREG=znak;
                    while (!TXIF);
                    __delay_ms(10);
                    TXSTAbits.TXEN=0;
            }
                cifra=0;
            bio=0; broj1=0; broj2=0; operacija=0;         
        }
    }
    return;
}